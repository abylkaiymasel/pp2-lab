﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week3
{
    class Asel
    {
        public FileSystemInfo[] lab
        {
            // get может только читать информацию из этого частного поля и возвращать ее.
            //set может записывать информацию только в это личное поле
            get;
            set;
        }
        int info;
        public int  Info
        {
            get
            {
                return info;
            }
            set
            {
                if (value < 0)
                {
                    info = lab.Length - 1;
                }
                else if (value >= lab.Length)
                {
                    info = 0;
                }
                else
                {
                    info = value; //Параметр value представляет передаваемое значение.
                }
            }
        }
        public void Studio()

        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            for (int i = 0; i < lab.Length; ++i)
            {
                if (i == Info)
                {
                    Console.BackgroundColor = ConsoleColor.Red;
                }
                else
                {
                    Console.BackgroundColor = ConsoleColor.Black;
                }
                Console.WriteLine(lab[i].Name);
            }
        }
    }
    enum FarMode // как справочник
    {
        FileView,
        DirectoryView
    }
    class Program
    {
        static void Main(string[] args)
        { 
            DirectoryInfo root = new DirectoryInfo(@"C:\Users\Asel\Desktop\practica");
            Stack<Asel> history = new Stack<Asel>();//stack- преставляет коллекцию переменного размера экзампляров одиноково заданного типа
            //обслуживаемую по принципу"последним пришел-первым вышел"
            FarMode farMode = FarMode.DirectoryView;

            //push-вставляет объект как верхний элемент стека
            history.Push(
                new Asel
                {
                    lab = root.GetFileSystemInfos(),
                  Info = 0
                });

            while (true)
            {
                if(farMode== FarMode.DirectoryView)
                {
                    history.Peek().Studio();//peek-возвращает объект в верхней части stack без его удаления
                }
                ConsoleKeyInfo consoleKeyInfo = Console.ReadKey();
                switch (consoleKeyInfo.Key)// swich/case - как if else, так как позволяет обработать сразу несколько условий

                {
                    case ConsoleKey.UpArrow:
                        history.Peek().Info--;
                        break;
                    case ConsoleKey.DownArrow:
                        history.Peek().Info++;
                        break;

                    case ConsoleKey.Enter:
                        int x = history.Peek().Info;
                        FileSystemInfo fileSystemInfo = history.Peek().lab[x];
                        if (fileSystemInfo.GetType() == typeof(DirectoryInfo))
                        {
                            DirectoryInfo d = fileSystemInfo as DirectoryInfo;
                            history.Push(new Asel { lab = d.GetFileSystemInfos(), Info = 0 });
                        }
                        else
                        {
                            farMode = FarMode.FileView;
                            using (FileStream fs = new FileStream(fileSystemInfo.FullName, FileMode.Open, FileAccess.Read))
                            {
                                //считывает символы из потока байтов в определ
                                using (StreamReader sr = new StreamReader(fs))
                                {
                                    Console.BackgroundColor = ConsoleColor.White;
                                    Console.ForegroundColor = ConsoleColor.Black;
                                    Console.Clear();
                                    Console.WriteLine(sr.ReadToEnd());
                                }
                            }
                        }
                        break;
                    case ConsoleKey.Backspace:
                        if (farMode == FarMode.DirectoryView)
                        {
                            history.Pop();// pop-удаляет и возвращает объект в верхней частей Stack
                        }
                        else if (farMode == FarMode.FileView)
                        {
                            farMode = FarMode.DirectoryView;
                            Console.ForegroundColor = ConsoleColor.White;
                        }
                        break;
                    case ConsoleKey.Delete:
                        int x2 = history.Peek().Info;
                        FileSystemInfo fileSystemInfo2 = history.Peek().lab[x2];
                        if (fileSystemInfo2.GetType() == typeof(DirectoryInfo))
                        {
                            DirectoryInfo d = fileSystemInfo2 as DirectoryInfo;
                            Directory.Delete(fileSystemInfo2.FullName, true);
                            history.Peek().lab = d.Parent.GetFileSystemInfos();
                        }
                        else
                        {
                            FileInfo f = fileSystemInfo2 as FileInfo;
                            File.Delete(fileSystemInfo2.FullName);
                            history.Peek().lab = f.Directory.GetFileSystemInfos();
                        }
                        history.Peek().Info--;
                        break;
                }
            }
        }
    }
}